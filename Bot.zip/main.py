import discord
from discord.ext import commands
from discord import app_commands
import os
from dotenv import load_dotenv
import asyncio

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
STATUS = os.getenv("STATUS", "Redeeming Keys 🗝️")

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

async def load_utils():
    """Load all utility scripts from ./utils"""
    for filename in os.listdir("./utils"):
        if filename.endswith(".py"):
            module_name = filename[:-3]
            try:
                __import__(f"utils.{module_name}")
                print(f"✅ Loaded util: {module_name}")
            except Exception as e:
                print(f"❌ Failed to load util {module_name}: {e}")

async def load_commands():
    """Load all commands/extensions from ./commands"""
    for filename in os.listdir("./commands"):
        if filename.endswith(".py"):
            module_name = filename[:-3]
            try:
                await bot.load_extension(f"commands.{module_name}")
                print(f"✅ Loaded command: {module_name}")
            except Exception as e:
                print(f"❌ Failed to load command {module_name}: {e}")

@bot.event
async def on_ready():

    await bot.change_presence(activity=discord.Game(STATUS))
    print(f"✅ Logged in as {bot.user} (ID: {bot.user.id})")

    try:
        synced = await bot.tree.sync()
        print(f"✅ Synced {len(synced)} global slash commands.")
    except Exception as e:
        print(f"❌ Failed to sync global commands: {e}")

async def main():
    """Load everything and start the bot"""
    async with bot:
        print("🔄 Loading utilities...")
        await load_utils()
        print("🔄 Loading commands...")
        await load_commands()
        print("🔄 Starting bot...")
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
